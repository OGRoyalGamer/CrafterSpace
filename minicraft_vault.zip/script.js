// ===========================
// MINICRAFT VAULT — script.js
// ===========================

// ---------------------------
// ITEMS ARRAY
// Agar apni khud ki PNG daalni ho to:
// 1. Image file apne folder mein rakho
// 2. src mein us file ka path likho jaise: "images/grass_block.png"
// 3. name mein icon ka naam likho
// ---------------------------
const ITEMS = [
  { name: "Grass Block",         src: "https://minecraft.wiki/images/thumb/Grass_Block_JE7_BE6.png/150px-Grass_Block_JE7_BE6.png" },
  { name: "Diamond Sword",       src: "https://minecraft.wiki/images/thumb/Diamond_Sword_JE2_BE2.png/150px-Diamond_Sword_JE2_BE2.png" },
  { name: "Diamond",             src: "https://minecraft.wiki/images/thumb/Diamond_JE3_BE3.png/150px-Diamond_JE3_BE3.png" },
  { name: "TNT",                 src: "https://minecraft.wiki/images/thumb/TNT_JE2_BE2.png/150px-TNT_JE2_BE2.png" },
  { name: "Creeper",             src: "https://minecraft.wiki/images/thumb/Creeper.png/150px-Creeper.png" },
  { name: "Steve",               src: "https://minecraft.wiki/images/thumb/Steve_default.png/150px-Steve_default.png" },
  { name: "Dirt Block",          src: "https://minecraft.wiki/images/thumb/Dirt_JE2_BE2.png/150px-Dirt_JE2_BE2.png" },
  { name: "Oak Log",             src: "https://minecraft.wiki/images/thumb/Oak_Log_(UD)_JE4_BE2.png/150px-Oak_Log_(UD)_JE4_BE2.png" },
  { name: "Crafting Table",      src: "https://minecraft.wiki/images/thumb/Crafting_Table_JE4_BE3.png/150px-Crafting_Table_JE4_BE3.png" },
  { name: "Chest",               src: "https://minecraft.wiki/images/thumb/Chest.png/150px-Chest.png" },
  { name: "Furnace",             src: "https://minecraft.wiki/images/thumb/Furnace_(S)_JE5_BE2.png/150px-Furnace_(S)_JE5_BE2.png" },
  { name: "Torch",               src: "https://minecraft.wiki/images/thumb/Torch_JE4_BE2.png/150px-Torch_JE4_BE2.png" },
  { name: "Apple",               src: "https://minecraft.wiki/images/thumb/Apple_JE3_BE3.png/150px-Apple_JE3_BE3.png" },
  { name: "Golden Apple",        src: "https://minecraft.wiki/images/thumb/Golden_Apple_JE2_BE2.png/150px-Golden_Apple_JE2_BE2.png" },
  { name: "Bow",                 src: "https://minecraft.wiki/images/thumb/Bow_(Pull_2)_JE1_BE1.png/150px-Bow_(Pull_2)_JE1_BE1.png" },
  { name: "Arrow",               src: "https://minecraft.wiki/images/thumb/Arrow_JE1_BE1.png/150px-Arrow_JE1_BE1.png" },
  { name: "Emerald",             src: "https://minecraft.wiki/images/thumb/Emerald_JE3_BE3.png/150px-Emerald_JE3_BE3.png" },
  { name: "Gold Ingot",          src: "https://minecraft.wiki/images/thumb/Gold_Ingot_JE4_BE2.png/150px-Gold_Ingot_JE4_BE2.png" },
  { name: "Iron Ingot",          src: "https://minecraft.wiki/images/thumb/Iron_Ingot_JE3_BE2.png/150px-Iron_Ingot_JE3_BE2.png" },
  { name: "Coal",                src: "https://minecraft.wiki/images/thumb/Coal_JE4_BE3.png/150px-Coal_JE4_BE3.png" },
  { name: "Netherite Ingot",     src: "https://minecraft.wiki/images/thumb/Netherite_Ingot_JE2_BE1.png/150px-Netherite_Ingot_JE2_BE1.png" },
  { name: "Ender Pearl",         src: "https://minecraft.wiki/images/thumb/Ender_Pearl_JE3_BE2.png/150px-Ender_Pearl_JE3_BE2.png" },
  { name: "Blaze Rod",           src: "https://minecraft.wiki/images/thumb/Blaze_Rod_JE1_BE1.png/150px-Blaze_Rod_JE1_BE1.png" },
  { name: "Book",                src: "https://minecraft.wiki/images/thumb/Book_JE2_BE2.png/150px-Book_JE2_BE2.png" },
  { name: "Enchanted Book",      src: "https://minecraft.wiki/images/thumb/Enchanted_Book_JE2_BE2.png/150px-Enchanted_Book_JE2_BE2.png" },
  { name: "Fishing Rod",         src: "https://minecraft.wiki/images/thumb/Fishing_Rod_JE2_BE2.png/150px-Fishing_Rod_JE2_BE2.png" },
  { name: "Bucket",              src: "https://minecraft.wiki/images/thumb/Bucket_JE2_BE2.png/150px-Bucket_JE2_BE2.png" },
  { name: "Water Bucket",        src: "https://minecraft.wiki/images/thumb/Water_Bucket_JE2_BE2.png/150px-Water_Bucket_JE2_BE2.png" },
  { name: "Lava Bucket",         src: "https://minecraft.wiki/images/thumb/Lava_Bucket_JE2.png/150px-Lava_Bucket_JE2.png" },
  { name: "Iron Sword",          src: "https://minecraft.wiki/images/thumb/Iron_Sword_JE2_BE2.png/150px-Iron_Sword_JE2_BE2.png" },
  { name: "Diamond Pickaxe",     src: "https://minecraft.wiki/images/thumb/Diamond_Pickaxe_JE3_BE3.png/150px-Diamond_Pickaxe_JE3_BE3.png" },
  { name: "Iron Axe",            src: "https://minecraft.wiki/images/thumb/Iron_Axe_JE3_BE2.png/150px-Iron_Axe_JE3_BE2.png" },
  { name: "Iron Shovel",         src: "https://minecraft.wiki/images/thumb/Iron_Shovel_JE2_BE2.png/150px-Iron_Shovel_JE2_BE2.png" },
  { name: "Diamond Hoe",         src: "https://minecraft.wiki/images/thumb/Diamond_Hoe_JE2_BE2.png/150px-Diamond_Hoe_JE2_BE2.png" },
  { name: "Iron Helmet",         src: "https://minecraft.wiki/images/thumb/Iron_Helmet_JE2_BE2.png/150px-Iron_Helmet_JE2_BE2.png" },
  { name: "Diamond Chestplate",  src: "https://minecraft.wiki/images/thumb/Diamond_Chestplate_JE3_BE2.png/150px-Diamond_Chestplate_JE3_BE2.png" },
  { name: "Golden Leggings",     src: "https://minecraft.wiki/images/thumb/Golden_Leggings_JE3_BE3.png/150px-Golden_Leggings_JE3_BE3.png" },
  { name: "Leather Boots",       src: "https://minecraft.wiki/images/thumb/Leather_Boots_JE3_BE2.png/150px-Leather_Boots_JE3_BE2.png" },
  { name: "Zombie",              src: "https://minecraft.wiki/images/thumb/Zombie.png/150px-Zombie.png" },
  { name: "Skeleton",            src: "https://minecraft.wiki/images/thumb/Skeleton.png/150px-Skeleton.png" },
  { name: "Enderman",            src: "https://minecraft.wiki/images/thumb/Enderman.png/150px-Enderman.png" },
  { name: "Spider",              src: "https://minecraft.wiki/images/thumb/Spider.png/150px-Spider.png" },
  { name: "Pig",                 src: "https://minecraft.wiki/images/thumb/Pig.png/150px-Pig.png" },
  { name: "Cow",                 src: "https://minecraft.wiki/images/thumb/Cow.png/150px-Cow.png" },
  { name: "Sheep",               src: "https://minecraft.wiki/images/thumb/Sheep.png/150px-Sheep.png" },
  { name: "Chicken",             src: "https://minecraft.wiki/images/thumb/Chicken.png/150px-Chicken.png" },
  { name: "Wolf",                src: "https://minecraft.wiki/images/thumb/Wolf.png/150px-Wolf.png" },
  { name: "Cat",                 src: "https://minecraft.wiki/images/thumb/Cat_orange_tuxedo.png/150px-Cat_orange_tuxedo.png" },
  { name: "Villager",            src: "https://minecraft.wiki/images/thumb/Villager.png/150px-Villager.png" },
  { name: "Iron Golem",          src: "https://minecraft.wiki/images/thumb/Iron_Golem.png/150px-Iron_Golem.png" },
  { name: "Ender Dragon",        src: "https://minecraft.wiki/images/thumb/Ender_Dragon.png/150px-Ender_Dragon.png" },
  { name: "Sand",                src: "https://minecraft.wiki/images/thumb/Sand_JE2_BE2.png/150px-Sand_JE2_BE2.png" },
  { name: "Gravel",              src: "https://minecraft.wiki/images/thumb/Gravel_JE2_BE2.png/150px-Gravel_JE2_BE2.png" },
  { name: "Stone",               src: "https://minecraft.wiki/images/thumb/Stone_JE2.png/150px-Stone_JE2.png" },
  { name: "Cobblestone",         src: "https://minecraft.wiki/images/thumb/Cobblestone_JE2_BE2.png/150px-Cobblestone_JE2_BE2.png" },
  { name: "Oak Planks",          src: "https://minecraft.wiki/images/thumb/Oak_Planks_JE5_BE3.png/150px-Oak_Planks_JE5_BE3.png" },
  { name: "Obsidian",            src: "https://minecraft.wiki/images/thumb/Obsidian_JE2_BE2.png/150px-Obsidian_JE2_BE2.png" },
  { name: "Bedrock",             src: "https://minecraft.wiki/images/thumb/Bedrock_JE2_BE2.png/150px-Bedrock_JE2_BE2.png" },
  { name: "Glass",               src: "https://minecraft.wiki/images/thumb/Glass_JE4_BE2.png/150px-Glass_JE4_BE2.png" },
  { name: "Nether Bricks",       src: "https://minecraft.wiki/images/thumb/Nether_Bricks_JE2_BE2.png/150px-Nether_Bricks_JE2_BE2.png" },
  { name: "Bookshelf",           src: "https://minecraft.wiki/images/thumb/Bookshelf_JE4_BE2.png/150px-Bookshelf_JE4_BE2.png" },
  { name: "Hay Bale",            src: "https://minecraft.wiki/images/thumb/Hay_Bale_(S)_JE2_BE2.png/150px-Hay_Bale_(S)_JE2_BE2.png" },
  { name: "Pumpkin",             src: "https://minecraft.wiki/images/thumb/Pumpkin_JE2_BE1.png/150px-Pumpkin_JE2_BE1.png" },
  { name: "Jack o Lantern",      src: "https://minecraft.wiki/images/thumb/Jack_o%27Lantern_JE2_BE2.png/150px-Jack_o%27Lantern_JE2_BE2.png" },
];

// ---------------------------
// CURRENT SELECTED ITEM (for modal)
// ---------------------------
let currentItem = null;

// ---------------------------
// RENDER GRID
// Takes an array of items and builds the HTML cards
// ---------------------------
function renderGrid(list) {
  const grid = document.getElementById('pngGrid');
  const noResults = document.getElementById('noResults');

  if (list.length === 0) {
    grid.innerHTML = '';
    noResults.style.display = 'block';
    return;
  }

  noResults.style.display = 'none';

  grid.innerHTML = list.map((item, index) => `
    <div class="png-card" onclick="openModal(${index}, '${item.src}', '${item.name.replace(/'/g, "\\'")}')">
      <img
        src="${item.src}"
        alt="${item.name}"
        onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2264%22 height=%2264%22><rect width=%2264%22 height=%2264%22 fill=%22%23333%22/><text x=%2232%22 y=%2240%22 text-anchor=%22middle%22 fill=%22%23666%22 font-size=%2224%22>?</text></svg>'"
      />
      <span class="iname">${item.name}</span>
    </div>
  `).join('');
}

// ---------------------------
// FILTER ITEMS BY SEARCH
// Called every time user types in the search bar
// ---------------------------
function filterItems() {
  const query = document.getElementById('searchInput').value.toLowerCase().trim();

  if (query === '') {
    renderGrid(ITEMS);
  } else {
    const filtered = ITEMS.filter(item =>
      item.name.toLowerCase().includes(query)
    );
    renderGrid(filtered);
  }
}

// ---------------------------
// OPEN MODAL
// Shows the clicked icon bigger with a download button
// ---------------------------
function openModal(index, src, name) {
  currentItem = { src, name };
  document.getElementById('modalImg').src = src;
  document.getElementById('modalName').textContent = name;
  document.getElementById('modalOverlay').classList.add('open');
}

// ---------------------------
// CLOSE MODAL (clicking outside the box)
// ---------------------------
function closeModal(event) {
  const overlay = document.getElementById('modalOverlay');
  if (event.target === overlay) {
    closeModalDirect();
  }
}

// ---------------------------
// CLOSE MODAL (clicking X button)
// ---------------------------
function closeModalDirect() {
  document.getElementById('modalOverlay').classList.remove('open');
  currentItem = null;
}

// ---------------------------
// DOWNLOAD ITEM
// Opens the image in a new tab for saving
// ---------------------------
function downloadItem() {
  if (!currentItem) return;

  const link = document.createElement('a');
  link.href = currentItem.src;
  link.download = currentItem.name.replace(/\s+/g, '_') + '.png';
  link.target = '_blank';
  link.click();
}

// ---------------------------
// INIT — render all items on page load
// ---------------------------
renderGrid(ITEMS);
